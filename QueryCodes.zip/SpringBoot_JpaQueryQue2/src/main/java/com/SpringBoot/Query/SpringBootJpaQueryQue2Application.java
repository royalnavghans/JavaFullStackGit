package com.SpringBoot.Query;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaQueryQue2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaQueryQue2Application.class, args);
	}

}
