package com.SpringBoot.Query.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.SpringBoot.Query.Jpa.LaptopJpa;
@Component
public class LaptopsRunner implements CommandLineRunner {
	@Autowired
LaptopJpa repo;
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

//		repo.FetchlaptopbypriceRange(50000,100000).forEach(System.out::println);
//		repo.FetchlaptopbyName("M2").forEach(System.out::println);
//		repo.FetchnamebyBrand("Apple").forEach(System.out::println);
//		repo.Fetchpricebybrand("Samsung").forEach(System.out::println);
//		repo.FetchdescriptionbyPriceandBrand(65000,"HP").forEach(System.out::println);
//		repo.SearchBrandbyName("vivoBook").forEach(System.out::println);
//		repo.FetchMaxPrice().forEach(System.out::println);
//		repo.FetchMinPrice().forEach(System.out::println);
//		repo.FetchAvgPrice().forEach(System.out::println);
//		repo.FetchTotalPrice().forEach(System.out::println);
//		repo.FetchCount().forEach(System.out::println);
//		
		
		
		
		Object[]obj=(Object[])repo.fetchAggregateData();
		
		System.out.println("Max sal "+obj[0]);
		System.out.println("Min sal "+obj[1]);
		System.out.println("Avg sal "+obj[2]);
		System.out.println("Total rows "+obj[3]);
		System.out.println("Sum of sal"+obj[4]);
	}

}
