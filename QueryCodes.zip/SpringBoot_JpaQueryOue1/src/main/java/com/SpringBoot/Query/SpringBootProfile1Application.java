package com.SpringBoot.Query;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProfile1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProfile1Application.class, args);
	}

}
