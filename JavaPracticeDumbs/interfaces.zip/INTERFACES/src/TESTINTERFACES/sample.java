package TESTINTERFACES;

public interface sample {

	public void Square();

	public void Circle();

	public void Rectangle();

	public void Triangle();
}
