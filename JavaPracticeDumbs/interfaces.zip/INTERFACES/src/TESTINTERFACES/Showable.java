package TESTINTERFACES;

public interface Showable {
	
	void show();  
	  interface Message{  
	   void msg();  
	  }  

}
