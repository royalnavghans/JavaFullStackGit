package day3;

public class Assignment2 {
	public static void main(String[] args) {
		System.out.println("Hello \nRajasekhar");
	}
}
