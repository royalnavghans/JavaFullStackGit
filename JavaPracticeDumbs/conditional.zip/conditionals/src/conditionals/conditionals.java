package conditionals;

public class conditionals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number = -5;

	    // checks if number is greater than 0
	    if (number > 0) {
	      System.out.println("The number is positive.");
	    }
	    
	    String language = "Java";

	    // if statement
	    if (language == "Java") {
	      System.out.println("Best Programming Language");
	    }

	    System.out.println("Statement outside if block");
	}

}
