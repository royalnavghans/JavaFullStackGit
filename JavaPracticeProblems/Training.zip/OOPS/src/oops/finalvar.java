package oops;

public class finalvar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // create a final variable
	    final int AGE = 32;

	    // try to change the final variable
	    AGE = 45;
	    System.out.println("Age: " + AGE);
	}

}
