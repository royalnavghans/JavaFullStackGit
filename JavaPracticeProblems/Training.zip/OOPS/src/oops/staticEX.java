package oops;

public class staticEX {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // accessing the methods of the Math class
        System.out.println("Absolute value of -12 =  " + Math.abs(-12));
        System.out.println("Value of PI = " + Math.PI);
        System.out.println("Value of E = " + Math.E);
        System.out.println("2^2 = " + Math.pow(2,2));
	}

}
