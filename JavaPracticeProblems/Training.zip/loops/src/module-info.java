/**
 * 
 */
/**
 * @author Nexwaveinc
 *
 */
module loops {
}