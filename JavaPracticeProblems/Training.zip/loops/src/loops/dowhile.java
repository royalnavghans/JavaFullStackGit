package loops;

public class dowhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	    int i = 1, n = 5;

	    // do...while loop from 1 to 5
	    do {
	      System.out.println(i);
	      i++;
	    } while(i <= n);
	}

}
