package loops;

public class foreach {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // create an array
	    int[] numbers = {3, 7, 5, -5};
	    
	    // iterating through the array 
	    for (int number: numbers) {
	       System.out.println(number);
	}

}
	
}
