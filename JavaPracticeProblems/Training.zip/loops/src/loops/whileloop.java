package loops;

public class whileloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// declare variables
	    int i = 1, n = 5;

	    // while loop from 1 to 5
	    while(i <= n) {
	      System.out.println(i);
	      i++;
	    }
	}

}
