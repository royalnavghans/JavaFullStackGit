package nw;

public class floatconv {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int a = 5;
		    int b = 2;
		    //float result = a/b;
		    float result = (float) a/b;
		    System.out.println("Result: " + result);

	}

}
