package nw;

public class implicit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int intVariable = 25;
	    long longVariable = intVariable;
	    float floatVariable = longVariable;
	    double doubleVariable = floatVariable;
	    System.out.println("Integer value is: " +intVariable);
	    System.out.println("Long value is: " +longVariable);
	    System.out.println("Float value is: " +floatVariable);
	    System.out.println("Double value is: " +doubleVariable);
	}

}
