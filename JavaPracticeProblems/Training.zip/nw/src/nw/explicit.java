package nw;

public class explicit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int intVariable = 10;
		    long longVariable = 7878;
		    //intVariable = longVariable;
		    
		  //Type Casting to int
		   intVariable = (int) longVariable;
		   System.out.println(intVariable);
	}

}
