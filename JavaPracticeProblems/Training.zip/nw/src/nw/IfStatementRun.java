package nw;

public class IfStatementRun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
