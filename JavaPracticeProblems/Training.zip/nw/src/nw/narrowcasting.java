package nw;

public class narrowcasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double myDouble = 9.78d;
	    int myInt = (int) myDouble; // Manual casting: double to int

	    System.out.println(myDouble);   // Outputs 9.78
	    System.out.println(myInt);      // Outputs 9
	}

}
