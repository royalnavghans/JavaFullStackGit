package operators;

public class TernaryOp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int februaryDays = 29;
	    String result;

	    // ternary operator
	    result = (februaryDays == 30) ? " leap year" : " not a Leap year";
	    System.out.println(result);
	}

}
