package operators;

public class ArithOp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // declare variables
	    int a = 12, b = 5; //hard coding 

	    // addition operator
	    System.out.println("a + b = " + (a + b));

	    // subtraction operator
	    System.out.println("a - b = " + (a - b));

	    // multiplication operator
	    System.out.println("a * b = " + (a * b));

	    // division operator
	    System.out.println("a / b = " + (a / b));

	    // modulo operator
	    System.out.println("a % b = " + (a % b));
	}

}
