package operators;

public class modulusop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Dividend
        int a = 15;
 
        // Divisor
        int b = 8;
 
        // Mod
        int k = a % b;
        System.out.println(k);
	}

}
