package operators;

public class AssignmentOp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// create variables
	    int a = 4;
	    int var;

	    // assign value using =
	    var = a;
	    System.out.println("var using =: " + var);

	    // assign value using =+
	    var += a;
	    System.out.println("var using +=: " + var);

	    // assign value using =*
	    var *= a;
	    System.out.println("var using *=: " + var);
	}

}
