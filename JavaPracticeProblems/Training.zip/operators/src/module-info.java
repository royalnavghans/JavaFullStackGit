/**
 * 
 */
/**
 * @author Nexwaveinc
 *
 */
module operators {
}